import{ab as e,A as t,B as c}from"./framework.2767c65f.js";const _={};function r(n,o){return t(),c("div")}const s=e(_,[["render",r],["__file","404.html.vue"]]);export{s as default};
