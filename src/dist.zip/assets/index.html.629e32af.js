import{ab as e,A as t,B as c}from"./framework.2767c65f.js";const n={};function r(_,o){return t(),c("div")}const s=e(n,[["render",r],["__file","index.html.vue"]]);export{s as default};
